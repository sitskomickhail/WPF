﻿
using BaseMapApp.CustomMarkers;
using GMap.NET;
using GMap.NET.MapProviders;
using GMap.NET.WindowsPresentation;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BaseMapApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

      
        // Текущий маркер
        GMapMarker currentMarker;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            gMapControl.MapProvider =GMapProviders.OpenStreetMap;
            GMap.NET.GMaps.Instance.Mode = GMap.NET.AccessMode.ServerAndCache;
            gMapControl.Position = new PointLatLng(54.6961334816182, 25.2985095977783);

            gMapControl.Bearing = 0;
            gMapControl.MaxZoom = 17;
            gMapControl.MinZoom = 2;
            gMapControl.Zoom = 15;
            gMapControl.MouseWheelZoomType = GMap.NET.MouseWheelZoomType.MousePositionAndCenter;
            gMapControl.CanDragMap = true;

            gMapControl.Position = new GMap.NET.PointLatLng(53.902800, 27.561759);
            gMapControl.CanDragMap = true;

            gMapControl.ShowCenter = false;

            gMapControl.MouseLeftButtonDown += gMapControl_MouseLeftButtonDown;

            AddDefaultMarker();
        }

        void gMapControl_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            System.Windows.Point p = e.GetPosition(gMapControl);
            GMapMarker NewMarker = new GMapMarker(gMapControl.Position);
            NewMarker.Shape = new CustomMarkerDemo(this, NewMarker, "Пользовательский маркер");
            NewMarker.Position = gMapControl.FromLocalToLatLng((int)p.X, (int)p.Y);
            gMapControl.Markers.Add(NewMarker);
        }

       private void AddDefaultMarker()
        {
            // установка координат для первого маркера! 
            currentMarker = new GMapMarker(gMapControl.Position);
            currentMarker.Shape = new CustomMarkerRed(this, currentMarker, "Маркер по умолчанию");
            currentMarker.Position = new GMap.NET.PointLatLng(53.902800, 27.561759);
            gMapControl.Markers.Add(currentMarker);
        }

       private void gMapControl_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
       {
         
       }
    }
}
